/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Singleton;

/**
 *
 * @author 96657
 */
public class Singletonclass {
    
    private static Singletonclass sSoleInstance;

    private  Singletonclass() {
    }
    
    public static Singletonclass getInstance(){
        if (sSoleInstance == null){
            sSoleInstance = new Singletonclass();
        }
        
        return sSoleInstance;
    }
    
    
    
    
}
