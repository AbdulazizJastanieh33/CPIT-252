package abstractfactorydemo;

public interface AbstractFactory {
    public Degree calculateTotalFee();
    public Diploma calculatetotalFee();

}
