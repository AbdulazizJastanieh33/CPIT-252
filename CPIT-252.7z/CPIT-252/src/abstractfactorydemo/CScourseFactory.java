/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactorydemo;

/**
 *
 * @author 2135813
 */
public class CScourseFactory implements AbstractFactory {

    @Override
    public Degree calculateTotalFee() {
        return new CSDegree();//to change body of genereated methods , choose tools templates.
    }

    @Override
    public Diploma calculatetotalFee() {
        return new CSDiploma();//to change body of genereated methods , choose tools templates.
    }
    
}
