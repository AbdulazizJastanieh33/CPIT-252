/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactorydemo;

import java.util.Scanner;

/**
 *
 * @author 2135813
 */
public class AbstractFactoryDemo {
    
    public static void main(String[]args){
        AbstractFactory factory;
        Degree degree;
        Diploma diploma;
        String program ="";
        System.out.println("enter program name to know fee");
        try (Scanner sc = new Scanner(System.in)){
            program = sc.next();
        }
        
        if (program.equalsIgnoreCase("IT")){
            factory = new ITcourseFactory();
            degree = factory.calculateTotalFee();
            degree.compute();
            diploma = factory.calculatetotalFee();
            diploma.compute();
            
        }
        else if (program.equalsIgnoreCase("CS")){
            factory = new CScourseFactory();
            degree = factory.calculateTotalFee();
            degree.compute();
            diploma = factory.calculatetotalFee();
            diploma.compute();
            
        }
        else {
            System.out.println("Not supported");
        }
    }
}
