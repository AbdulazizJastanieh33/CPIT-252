/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactorydemo1;

/**
 *
 * @author 2135813
 */
public class SamsungProductFactory implements AbstractFactory {

    @Override
    public Phone createPhone(String type) {
       return new SamsungPhone();
    }

    @Override
    public Tablet createTablet(String type) {
        return new SamsungTablet();
    }
    
    
}
