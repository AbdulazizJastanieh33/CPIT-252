/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factorydemo;

/**
 *
 * @author 96657
 */
public class GetPlanFactory {
    //use getPlan method to get object of type plan
    
    public Plan getPlan(String planType){
        if (planType ==null){
            return null;
        }
        
        if (planType.equalsIgnoreCase("DOMESTICPLAN")){
            return new DomesticPlan();
        }
        else if (planType.equalsIgnoreCase("COMMERCIALPLAN")){
            return new CommercialPlan();
            
        }
        else if (planType.equalsIgnoreCase("INSTITUTIONALPLAN")){
            return new InstitutionalPlan();
            
        }
        return null;
    }
}
