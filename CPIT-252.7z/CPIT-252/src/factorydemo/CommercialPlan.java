/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factorydemo;

/**
 *
 * @author 96657
 */
public class CommercialPlan extends Plan {
    
    
    public void getRate(){
        rate = 7.5;
    }
    
    
}
