/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package courseinfo;

/**
 *
 * @author 96657
 */
public class Health extends Course {

    @Override
    public void getDuration() {
        duration = 10;
        System.out.println(duration);
    }

    @Override
    public void getFeePerSemester() {
        fee = 5000;
        System.out.println(fee);
    }
    
}
