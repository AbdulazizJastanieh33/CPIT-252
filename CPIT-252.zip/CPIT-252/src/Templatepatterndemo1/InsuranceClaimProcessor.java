/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo1;

/**
 *
 * @author 96657
 */
public abstract class InsuranceClaimProcessor {
     public final void processClaim(){
        logClaim();
        validateClaim();
        calculatePayment();
        approveClaim();
        sendNotification();
    }

    private void logClaim(){
        System.out.println("Claim logged at: " + java.time.LocalDate.now());
    }

    // Methods to be implemented by subclasses based on specific claim tyoe
    abstract void validateClaim();
    abstract void calculatePayment();
    abstract void approveClaim();

    private void sendNotification() {
        System.out.println("Notification sent to the claimant.\n");
    }
    
    
}
