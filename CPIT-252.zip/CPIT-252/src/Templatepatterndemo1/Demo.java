/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo1;

/**
 *
 * @author 96657
 */
public class Demo {
    public static void main(String[] args) {
        InsuranceClaimProcessor healthClaim = new HealthClaim();
        InsuranceClaimProcessor autoClaim = new AutoClaim();
        InsuranceClaimProcessor lifeCalim = new LifeClaim();

        healthClaim.processClaim();
        autoClaim.processClaim();
        lifeCalim.processClaim();
    }
}
