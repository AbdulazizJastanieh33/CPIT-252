/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo1;

/**
 *
 * @author 96657
 */
public class LifeClaim extends InsuranceClaimProcessor{
    @Override
    void validateClaim() {
        System.out.println("Validating life claim.");
    }

    @Override
    void calculatePayment() {
        System.out.println("Calculating payment for life claim.");
    }

    @Override
    void approveClaim() {
        System.out.println("Approving life claim.");
    }
    
    
}
