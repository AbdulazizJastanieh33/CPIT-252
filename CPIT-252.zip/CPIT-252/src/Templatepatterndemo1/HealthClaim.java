/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo1;

/**
 *
 * @author 96657
 */
public class HealthClaim extends InsuranceClaimProcessor{
    @Override
    void validateClaim() {
        System.out.println("Validating health claim.");
    }

    @Override
    void calculatePayment() {
        System.out.println("Calculating payment for health claim.");
    }

    @Override
    void approveClaim() {
        System.out.println("Approving health claim.");
    }
    
}
