/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factorydemo;

/**
 *
 * @author 96657
 */

import java.io.*;
public class GenerateBill {
    public static void main(String[]args) throws IOException{
        GetPlanFactory planFactory = new GetPlanFactory();
        
        System.out.println("enter the name of plan for which the bill will be generated");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        String planName = br.readLine();
        
        System.out.println("enter the numbef of units for bill will be calculated");
        int units = Integer.parseInt(br.readLine());
        
        Plan p = planFactory.getPlan(planName);
        //call getRate method and calculate Bill method of plan
        
        System.out.println("Bill amount for " + planName + "of "+ units + "units is:");
        p.getRate();
        p.calculateBill(units);
    }
}
