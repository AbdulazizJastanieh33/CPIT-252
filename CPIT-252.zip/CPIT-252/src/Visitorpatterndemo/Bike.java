/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Visitorpatterndemo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 96657
 */
public class Bike implements Visitable{
    private List<Visitable> bikeParts = new ArrayList<Visitable>();

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
        for (Visitable part: bikeParts){
            part.accept(visitor);
        }
    }
    
    public void addBikePart(Visitable part){
        bikeParts.add(part);
    }
    
}
