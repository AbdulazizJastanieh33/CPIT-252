/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Visitorpatterndemo;

/**
 *
 * @author 96657
 */
public class Demo {
    public static void main(String[]args){
        Bike bike = new Bike();
        Visitable engine = new Engine();
        Visitable fuelTank = new FuelTank();
        bike.addBikePart(fuelTank);
        bike.addBikePart(engine);
        bike.accept(new PartsChecker());
        bike.accept(new PartsOperator());
        
        
    }
}
