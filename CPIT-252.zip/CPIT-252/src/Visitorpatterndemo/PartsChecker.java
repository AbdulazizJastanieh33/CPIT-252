/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Visitorpatterndemo;

/**
 *
 * @author 96657
 */
public class PartsChecker implements Visitor{

    @Override
    public void visit(FuelTank fuelTank) {
        System.out.println("Checking whether there is fuel in fuel tank");
    }
    @Override
    public void visit(Engine engine){
        System.out.println("Checking whether ingnition switch is on");
    }
    @Override
    public void visit(Bike bike){
        System.out.println("Going to the bike");
    }
    
    
    
}
