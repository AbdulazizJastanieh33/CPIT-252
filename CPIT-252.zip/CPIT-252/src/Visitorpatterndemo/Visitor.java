/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Visitorpatterndemo;

/**
 *
 * @author 96657
 */
public interface Visitor {
    public abstract void visit(FuelTank fuelTank);
    public abstract void visit(Engine engine);
    public abstract void visit(Bike bike);
    
}
