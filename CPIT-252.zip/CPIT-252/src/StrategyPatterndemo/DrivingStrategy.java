/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StrategyPatterndemo;

/**
 *
 * @author 2135813
 */
public class DrivingStrategy implements RouteStrategy{

    @Override
    public void calculateRoute(String origin, String destination) {
        System.out.println("Calculating driving route from " + origin + "to " + destination + ".");
    }
    
    
    
}
