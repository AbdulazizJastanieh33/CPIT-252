/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StrategyPatterndemo;

/**
 *
 * @author 96657
 */
public class StrategyPatternDemo {
    public static void main(String[]args){
        RoutePlanner planner = new RoutePlanner(new DrivingStrategy());
        planner.planRoute("Al Rehab", "Sulemania");
        
        //changing strategy to bicycling
        
        planner.setRouteStrategy(new BicyclingStrategy());
        planner.planRoute("Al Rehab", "Sulemania");
        
        //changing strategy to public transport 
        
        planner.setRouteStrategy(new PublicTransportStrategy());
        planner.planRoute("Al Rehab", "Sulemania");
    }
    
    
}
