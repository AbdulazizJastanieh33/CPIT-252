/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StrategyPatterndemo;

/**
 *
 * @author 96657
 */
public class RoutePlanner {
    private RouteStrategy strategy;

    public RoutePlanner(RouteStrategy strategy) {
        this.strategy = strategy;
    }
    
    public void setRouteStrategy(RouteStrategy strategy){
        this.strategy = strategy;
    }
    
    public void planRoute(String origin, String destination){
        strategy.calculateRoute(origin, destination);
    }
    
    
}
