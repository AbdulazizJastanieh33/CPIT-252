/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterncustomer;

/**
 *
 * @author 96657
 */
public class ChineseFood extends FoodDecorator{
    
    public ChineseFood(Food newFood){
        
        super(newFood);
    }
    
    @Override
    public String prepareFood(){
        
        return super.prepareFood() + "With Fried Rice and Manchurlan";
    }
    
    @Override
    public double foodPrice(){
        
        return super.foodPrice() + 75;
    }
    
    
}
