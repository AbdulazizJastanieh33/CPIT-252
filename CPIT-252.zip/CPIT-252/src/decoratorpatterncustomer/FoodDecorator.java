/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterncustomer;

/**
 *
 * @author 96657
 */
public abstract class FoodDecorator implements Food {
    
    private Food newFood;
    
    public FoodDecorator(Food newFood){
        
        this.newFood=newFood;
    }
    
    @Override
    public String prepareFood(){
        return newFood.prepareFood();
    }
    
    @Override
    public double foodPrice(){
        
        return newFood.foodPrice();
    }
    
    
}
