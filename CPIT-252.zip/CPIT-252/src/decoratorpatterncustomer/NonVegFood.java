/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterncustomer;

/**
 *
 * @author 96657
 */
public class NonVegFood extends FoodDecorator {
    
    public NonVegFood(Food newFood){
        
        super(newFood);
    }
    
    @Override
    public String prepareFood(){
        
        return super.prepareFood() + "with Roasted Chicken";
    }
    
    @Override
    public double foodPrice(){
        
        return super.foodPrice() + 150;
        
    }
    
}
