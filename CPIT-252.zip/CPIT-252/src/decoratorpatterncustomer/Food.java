/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterncustomer;

/**
 *
 * @author 96657
 */
public interface Food {
    
    
    public String prepareFood();
    
    public double foodPrice();
    
    
}
