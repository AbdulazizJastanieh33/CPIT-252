/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Singleton;

/**
 *
 * @author 96657
 */
public class Singleton {
    public static void main(String[]args){
        //instance 1 
        Singletonclass instance1 = Singletonclass.getInstance();
        
        //instance 2
        Singletonclass instance2 = Singletonclass.getInstance();
        
        System.out.println("Instance 1 hash:" + instance1.hashCode());
        
        System.out.println("Instance 2 hash:" + instance2.hashCode());
    }
}
