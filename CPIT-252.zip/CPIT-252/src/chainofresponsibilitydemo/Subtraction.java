/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibilitydemo;

/**
 *
 * @author 96657
 */
public class Subtraction implements Handler{
    public Handler nextHandler;

    @Override
    public void nextHandler(Handler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void processRequest(Numbers request) {
        if (request.getOperation() == "SUBTRACT"){
            int number1 = request.getNumber1();
            int number2 = request.getNumber2();
            int sum = number1 - number2;
            System.out.println(number1 + " - " + number2 + " = " + sum);
        }
        else {
            nextHandler.processRequest(request);
        }
    }
}
