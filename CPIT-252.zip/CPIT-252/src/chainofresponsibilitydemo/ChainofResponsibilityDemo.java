/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibilitydemo;

/**
 *
 * @author 96657
 */
public class ChainofResponsibilityDemo {
    public static void main(String[]args){
        Handler handler1 = new Addition();
        Handler handler2 = new Subtraction();
        Handler handler3 = new Multiply();
        
        handler1.nextHandler(handler2);
        handler2.nextHandler(handler3);
        //Addtion
        Numbers request = new Numbers(10, 2, "ADD");
        handler1.processRequest(request);
        
        //Subtraction
        request = new Numbers(10, 2, "SUBTRACT");
        handler1.processRequest(request);
        
        //Multiply
        request = new Numbers(10, 2, "MULTIPLY");
        handler1.processRequest(request);
        
    }
    
    
}
