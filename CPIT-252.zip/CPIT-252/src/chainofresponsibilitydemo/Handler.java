/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibilitydemo;

/**
 *
 * @author 96657
 */
public interface Handler {
    
    public void nextHandler(Handler nextHandler);
    public void processRequest(Numbers request);
}
