/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVCdemo2;

/**
 *
 * @author 2135813
 */
public class EmployeeController {
    private EmployeeM model;
    private EmployeeView view;
    
    //constructer

    public EmployeeController(EmployeeM model, EmployeeView view) {
        this.model = model;
        this.view = view;
    }
    
    //getter and setter methods
    
    public void setEmployeeName(String name){
        model.setEmployeeName(name);
    }
    
    public String getEmployeeName(){
        return model.getEmployeeName();
    }
    
    public void setEmployeeId(String id){
        model.setEmployeeId(id);
        
    }
    
    public String getEmployeeId(){
        return model.getEmployeeId();
    }
    
    public void setEmployeeDepartment(String Department){
        model.setEmployeeDepartment(Department);
    }
    
    public String getEmployeeDepartment(){
        return model.getEmployeeDepartment();
    }
    
    //method to update view
    public void updateView(){
        view.printEmployeeDetails(model.getEmployeeName(), model.getEmployeeId(), model.getEmployeeDepartment());
    }
    
    
}
