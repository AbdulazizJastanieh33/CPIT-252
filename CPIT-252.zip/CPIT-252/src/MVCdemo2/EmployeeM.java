/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVCdemo2;

/**
 *
 * @author 2135813
 */
public class EmployeeM {
    private String EmployeeName;
    private String EmployeeId;
    private String EmployeeDepartment;
    
    //defining getter and setter methods

    public EmployeeM(String EmployeeName, String EmployeeId, String EmployeeDepartment) {
        this.EmployeeName = EmployeeName;
        this.EmployeeId = EmployeeId;
        this.EmployeeDepartment = EmployeeDepartment;
    }
    
    public EmployeeM(){
        
    }
    
    public String getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(String EmployeeId) {
        this.EmployeeId = EmployeeId;
    }

    public String getEmployeeDepartment() {
        return EmployeeDepartment;
    }

    public void setEmployeeDepartment(String EmployeeDepartment) {
        this.EmployeeDepartment = EmployeeDepartment;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }
    
    
}
