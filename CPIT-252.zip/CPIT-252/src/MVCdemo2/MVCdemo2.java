/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVCdemo2;

/**
 *
 * @author 2135813
 */
public class MVCdemo2 {
    public static void main(String[]args){
        //fetching the employee record based on the employee_id from the database
        
        EmployeeM model = retrieveEmployee(); 
        
        
        
        //creating a view to write employee m details on console
                
        EmployeeView view = new EmployeeView();
        
        EmployeeController controller = new EmployeeController(model, view);
        
        controller.updateView();
        
        //updating the model data
        
        controller.setEmployeeName("Yahya");
        
        System.out.println("\nEmployee details after updating: ");
        
        controller.updateView();
        
        
    }
    
    private static EmployeeM retrieveEmployee(){
        EmployeeM Employee = new EmployeeM();
        Employee.setEmployeeName("Burhan");
        Employee.setEmployeeId("11");
        Employee.setEmployeeDepartment("Salesforce");
        return Employee;
    }
    
    
}
