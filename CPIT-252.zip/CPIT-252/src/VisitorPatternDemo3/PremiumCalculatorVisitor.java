/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VisitorPatternDemo3;

/**
 *
 * @author 96657
 */
public class PremiumCalculatorVisitor implements InsurancePlanVisitor{

    @Override
    public void visit(HealthInsurancePlan plan) {
        System.out.println("Calculating premium for heatlh insurance");
    }

    @Override
    public void visit(LifeInsurancePlan plan) {
        System.out.println("Calculating premium for life insurance");
    }

    @Override
    public void visit(AutoInsurancePlan plan) {
        System.out.println("Calculating premium for auto insurance");
    }
    
}
