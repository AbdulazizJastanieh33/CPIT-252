/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VisitorPatternDemo3;

/**
 *
 * @author 96657
 */
public class Demo {
    public static void main(String[]args){
        InsurancePlan healthPlan = new HealthInsurancePlan();
        InsurancePlan lifePlan = new LifeInsurancePlan();
        InsurancePlan autoPlan = new AutoInsurancePlan();
        
        PremiumCalculatorVisitor premiumVisitor = new PremiumCalculatorVisitor();
        BenefitsDescriptionVisitor benefitsVisitor = new BenefitsDescriptionVisitor();
        
        healthPlan.accept(premiumVisitor);
        lifePlan.accept(premiumVisitor);
        autoPlan.accept(premiumVisitor);
        
        healthPlan.accept(benefitsVisitor);
        lifePlan.accept(benefitsVisitor);
        autoPlan.accept(benefitsVisitor);
    }
}
