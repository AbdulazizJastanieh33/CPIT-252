/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VisitorPatternDemo3;

/**
 *
 * @author 96657
 */
public class LifeInsurancePlan implements InsurancePlan{

    @Override
    public void accept(InsurancePlanVisitor visitor) {
        visitor.visit(this);
    }
    
}
