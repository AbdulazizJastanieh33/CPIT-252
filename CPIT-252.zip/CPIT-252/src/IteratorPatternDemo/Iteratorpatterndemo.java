/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IteratorPatternDemo;

/**
 *
 * @author 96657
 */
public class Iteratorpatterndemo {
    public static void main(String[]args){
        CourseCollection courseCollection = new CourseCollection();
        courseCollection.addCourse(new Course("Introduction to Java", "CS101"));
        courseCollection.addCourse(new Course("Data Structers", "CS201"));
        courseCollection.addCourse(new Course("operatin systems", "CS301"));
        
        System.out.println("Available Courses: ");
        for (Course course: courseCollection){
            System.out.println(course);
        }
    }
}
