/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IteratorPatternDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author 96657
 */
public class CourseCollection implements Iterable<Course>{
    private List<Course> courses = new ArrayList<>();
    
    public void addCourse(Course course){
        courses.add(course);
    }

    @Override
    public Iterator<Course> iterator() {
        return new CourseIterator();
    }
    
    public class CourseIterator implements Iterator<Course>{
    private int currentindex = 0;

    @Override
    public boolean hasNext() {
        return currentindex < courses.size();
    }

    @Override
    public Course next() {
        return courses.get(currentindex++);
    }
    
    
}
}
