/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategypatterndemo2;

/**
 *
 * @author 96657
 */
public class StrategyPatterndemo2 {
    public static void main(String[]args){
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(new Item("1234",110));
        cart.addItem(new Item("5678",210));
        //pay by paypal
        cart.setPaymentStrategy(new PaypalPaymentStrategy("myemail@example.com","mypassword"));
        cart.checkout();
        
        //switch payment to credit card
        cart.setPaymentStrategy(new CreditCardpaymentStrategy("Rizwan Jameel", "1234567890123456","786","12/24"));
        cart.checkout();
    }
}
