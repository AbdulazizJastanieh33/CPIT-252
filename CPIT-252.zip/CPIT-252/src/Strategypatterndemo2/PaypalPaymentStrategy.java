/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategypatterndemo2;

/**
 *
 * @author 96657
 */
public class PaypalPaymentStrategy implements PaymentStrategy{
    private String emailId;
    private String password;

    public PaypalPaymentStrategy(String email, String password) {
        this.emailId = email;
        this.password = password;
    }

    @Override
    public void pay(int amount) {
        System.out.println(amount + "paid using Paypal.");
    }
    
    
}
