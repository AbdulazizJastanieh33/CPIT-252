/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo;

/**
 *
 * @author amsum
 */
public class Poor implements State
{
    public void saySomething(StateContext sc)
    {
        System.out.println("I'm poor currently, and spend much time working");
        sc.changeState(new Rich());
    }
    
}
