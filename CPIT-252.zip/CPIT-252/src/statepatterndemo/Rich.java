/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo;

/**
 *
 * @author amsum
 */
public class Rich implements State
{
    public void saySomething(StateContext sc)
    {
        System.out.println("I'm rich currently, and play a lot.");
        sc.changeState(new Poor());
    }
    
}
