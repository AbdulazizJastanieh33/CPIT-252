/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo;

/**
 *
 * @author amsum
 */
public class StateContext 
{
    private State currentState;
    
    public StateContext()
    {
        currentState = new Poor();
    }
    
    public void changeState(State newState)
    {
        this.currentState = newState;
    }
    
    public void saySomething()
    {
        this.currentState.saySomething(this);
    }
    
}
