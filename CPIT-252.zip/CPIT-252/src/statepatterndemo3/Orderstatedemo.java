/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo3;

/**
 *
 * @author 2135813
 */
public class Orderstatedemo {
    public static void main(String[]args){
        OrderContext order = new OrderContext();
        order.processingOrder();
        order.shipOrder();
        order.deliverOrder();
        order.cancelOrder();
        
}
}
