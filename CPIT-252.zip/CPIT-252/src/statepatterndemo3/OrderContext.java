/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo3;

/**
 *
 * @author 2135813
 */
public class OrderContext {
    private OrderState state;
    
    public OrderContext(){
        state = new ProcessingState();
    }
    
    public void setState(OrderState state){
        this.state = state;
    }
    
    public void processingOrder(){
        state.processOrder(this);
    }
    
    public void shipOrder(){
        state.shipOrder(this);
    }
    
    public void deliverOrder(){
        state.deliverOrder(this);
    }
    
    public void cancelOrder(){
        state.cancelOrder(this);
    }
    
    
}
