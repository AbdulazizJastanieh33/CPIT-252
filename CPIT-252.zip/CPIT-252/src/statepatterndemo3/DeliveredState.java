/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo3;

/**
 *
 * @author 2135813
 */
public class DeliveredState implements OrderState{
    public void processOrder(OrderContext context){
        System.out.println("Order has already been delivered");
    }
    
    public void shipOrder(OrderContext context){
        System.out.println("Order has already been delivered");
    }
    
    public void deliverOrder(OrderContext context){
        System.out.println("Order has already been delivered");
    }
    
    public void cancelOrder(OrderContext context){
        System.out.println("Cannot cancel, order has already been delivered");
    }
    
    
}
