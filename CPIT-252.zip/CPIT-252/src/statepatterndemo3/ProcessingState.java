/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statepatterndemo3;

/**
 *
 * @author 2135813
 */
public class ProcessingState implements OrderState{
    public void processOrder(OrderContext context){
        System.out.println("Order is already being processed");
        context.setState(new ShippedState());
    }
    
    public void shipOrder(OrderContext context){
        System.out.println("Shipping you order now");
        context.setState(new ShippedState());
    }
    
    public void deliverOrder(OrderContext context){
        System.out.println("Order Must be shipped");
    }
    
    public void cancelOrder(OrderContext context){
        System.out.println("Order processing cancelled");
        context.setState(new CancelledState());
    }
}
