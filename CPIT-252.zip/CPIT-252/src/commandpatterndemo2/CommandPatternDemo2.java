/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package commandpatterndemo2;

/**
 *
 * @author 96657
 */
public class CommandPatternDemo2 {
    public static void main(String[]args){
        Stock abcStock = new Stock();
        
        BuyStock buyStockOrder = new BuyStock(abcStock);
        
        SellStock sellStockOrder = new SellStock(abcStock);
        
        Broker broker = new Broker();
        
        broker.placeOrders(buyStockOrder);
        
        broker.placeOrders(sellStockOrder);
        
        
    }
    
    
}
