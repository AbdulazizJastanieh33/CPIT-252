/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BuilderPatternDemo;

/**
 *
 * @author 96657
 */
public class SmallCoke extends Coke {
    @Override
    public String name() {
        return "300 ml Coke";
    }

    @Override
    public String size() {
        return "Small Size";
    }

    @Override
    public int price() {
        return 25   ;
    }
}
