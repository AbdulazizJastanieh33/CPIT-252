/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BuilderPatternDemo;

import java.io.IOException;

/**
 *
 * @author 96657
 */
public class BuilderpatternDemo {
    public static void main(String[] args) throws IOException {
        OrderBuilder builder = new OrderBuilder();
        OrderedItems orderedItems = builder.preparePizza();
        orderedItems.showItems();
        System.out.println("\n");
        System.out.println("Total Cost : "+orderedItems.getCost());

    }
    
}
