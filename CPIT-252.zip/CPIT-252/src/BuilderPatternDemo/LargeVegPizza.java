/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BuilderPatternDemo;

/**
 *
 * @author 96657
 */
public class LargeVegPizza extends VegPizza {
   
    @Override
    public int price()
    {
        return 180;
    }

    @Override
    public String name()
    {
        return "Large Veg Pizza";
    }

    @Override
    public String size()
    {
        return "Large Size";
    }
    
    
}
