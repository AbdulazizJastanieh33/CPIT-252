/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BuilderPatternDemo;

/**
 *
 * @author 96657
 */
public abstract class Coke extends ColdDrink {
    @Override
    public abstract String name();
    @Override
    public abstract String size();

    @Override
    public abstract int price();
    
}
