/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BuilderPatternDemo;

/**
 *
 * @author 96657
 */
public class SmallVegPizza extends VegPizza{
    
    @Override
    public int price() {
        return 120;
    }

    @Override
    public String name() {
        return "Small Veg Pizza";
    }

    @Override
    public String size() {
        return "Small Size";
    }
    
}
