/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactorydemo1;

/**
 *
 * @author 2135813
 */
public class Ipad extends Tablet {
    
    public Ipad(){
        name = "ipad";
    }
    
    
}
