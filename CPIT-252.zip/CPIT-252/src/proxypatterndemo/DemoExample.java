/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proxypatterndemo;

/**
 *
 * @author 96657
 */
public class DemoExample {
    
    public static void main(String[]args){
        
        Rectangle shape = new Rectangle();
        shape.display();
    }
}
