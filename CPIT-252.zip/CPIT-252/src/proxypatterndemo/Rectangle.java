/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proxypatterndemo;

/**
 *
 * @author 96657
 */
public class Rectangle extends Circle{
    
    @Override
    public void display(){
        System.out.println("The Rectangle child class acts as proxy \n");
        super.display();
    }
    
    
}
