/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVCdemo1;

/**
 *
 * @author 2135813
 */
public class MVCdemo {
    public static void main(String[]args){
        //create a book instance
        
        Bookm book = new Bookm("Effective Java","Joshua Bloch", 39.99);
        
        //create a book view instance
        
        BookView view = new BookView();
        
        //create a book controller instance
        
        BookController controller = new BookController(book, view);
        //display the initial book details
        controller.updateView();
        
        //update the book details and display the updated details
        
        controller.setBookTitle("Clean Code");
        
        controller.setBookAuthor("Robert C. Martin");
        
        controller.setBookPrice(34.99);
        
        controller.updateView();
        
        
    }
}
