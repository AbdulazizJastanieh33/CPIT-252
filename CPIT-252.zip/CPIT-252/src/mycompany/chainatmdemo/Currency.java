/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mycompany.chainatmdemo;

/**
 *
 * @author 96657
 */
public class Currency {
    private int amount;
    
    public Currency(int amt){
        this.amount = amt;
    }
    public int getAmount(){
        return this.amount;
    }
    
    
}
