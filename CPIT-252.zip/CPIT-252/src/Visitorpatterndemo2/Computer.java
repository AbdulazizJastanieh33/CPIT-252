/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Visitorpatterndemo2;

/**
 *
 * @author 96657
 */
public class Computer implements ComputerPart{
    ComputerPart[] parts;
    
    public Computer(){
        parts = new ComputerPart[]{
            new Mouse(),new Keyboard(), new Monitor()
        };
    }
    
    public void accept(ComputerPartVisitor ComputerPartVisitor){
        for (int i= 0; i< parts.length; i++){
        parts[i].accept(ComputerPartVisitor);
        
    }
        ComputerPartVisitor.visit(this);
    }
    
    
    
}
