/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package courseinfo;

/**
 *
 * @author 96657
 */
public class Admission {
    public Course admittingCourse(String courseName){
        if (courseName == null){
            return null;
        }
        if (courseName.equalsIgnoreCase("Computer")){
            return new Computer();
        }
        else if (courseName.equalsIgnoreCase("CivilServices")){
            return new CivilServices();
        }
        else if (courseName.equalsIgnoreCase("Health")){
            return new Health();
        }
        return null;
    }
}
