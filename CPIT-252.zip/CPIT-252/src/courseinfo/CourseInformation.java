/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package courseinfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author 96657
 */
public class CourseInformation {
    public static void main(String args[]) throws IOException{
        Admission newApplication = new Admission();
        System.out.println("enter the course you are trying to admit in");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String courseName = br.readLine();
        Course obj = newApplication.admittingCourse(courseName);
        System.out.println("For "+ courseName + "the required duration is ");
        obj.getDuration();
        System.out.println("For "+ courseName + "the required fee is ");
        obj.getFeePerSemester();
        System.out.println("the total fee is ");
        obj.calculateTotalFee();
        
    }
}
