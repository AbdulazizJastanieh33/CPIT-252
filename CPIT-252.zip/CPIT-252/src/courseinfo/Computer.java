/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package courseinfo;

/**
 *
 * @author 96657
 */
public class Computer extends Course {

    @Override
    public void getDuration() {
       duration =8;
       System.out.println(duration);
    }

    @Override
    public void getFeePerSemester() {
        fee = 3000;
        System.out.println(fee);
    }
    
}
