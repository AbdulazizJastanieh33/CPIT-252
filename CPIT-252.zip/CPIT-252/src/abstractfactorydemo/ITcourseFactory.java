/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactorydemo;

/**
 *
 * @author 2135813
 */
public class ITcourseFactory implements AbstractFactory{

    @Override
    public Degree calculateTotalFee() {
        return new ITDegree();
    }

    @Override
    public Diploma calculatetotalFee() {
        return new ITDiploma();
    }
    
}
