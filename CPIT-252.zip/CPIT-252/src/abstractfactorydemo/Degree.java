
package abstractfactorydemo;
abstract class Degree {
    int fee;
    int duration;
    abstract void compute();
    
    
}
