/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementodesignpattern1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 96657
 */
public class CareTaker {
    private List statesList = new ArrayList();
    
    public void addMemento(Memento m){
        statesList.add(m);
    }
    
    public Memento getMemento(int index){
        return (Memento) statesList.get(index);
    }
    
    
}
