/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementodesignpattern1;

/**
 *
 * @author 96657
 */
public class MementoDesignPattern1 {
    
    public static void main(String[]args){
        Originator originator = new Originator();
        originator.setState("lion");
        Memento memento = originator.createMemento();
        
        CareTaker caretaker = new CareTaker();
        
        caretaker.addMemento(memento);
        
        originator.setState("tiger");
        originator.setState("Horse");
        
        memento = originator.createMemento();
        
        caretaker.addMemento(memento);
        
        originator.setState("Elephant");
        System.out.println("Originator Current State:" + originator.getState());
        System.out.println("Originator restoring to previous state...");
        memento = caretaker.getMemento(1);
        
        originator.setMemento(memento);
        
        System.out.println("Originator Current State:" + originator.getState());
        System.out.println("Again  restoring to previous state...");
        
        memento = caretaker.getMemento(0);
        
        originator.setMemento(memento);
        System.out.println("Originator Current state:" + originator.getState());
        
        
    }
}
