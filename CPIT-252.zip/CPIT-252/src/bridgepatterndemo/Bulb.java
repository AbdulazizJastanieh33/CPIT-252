/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridgepatterndemo;

/**
 *
 * @author 96657
 */
public class Bulb implements Switch{

    @Override
    public void switchOn() {
        System.out.println("BULB Switched ON");
    }

    @Override
    public void switchOff() {
        System.out.println("BULB Switched OFF");
    }
    
}
