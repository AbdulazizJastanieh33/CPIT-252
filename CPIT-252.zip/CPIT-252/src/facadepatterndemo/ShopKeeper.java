/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facadepatterndemo;

/**
 *
 * @author 96657
 */
public class ShopKeeper {
    private MobileShop Iphone;
    private MobileShop samsung;
    private MobileShop blackberry;
    
    public ShopKeeper(){
        Iphone = new IPhone();
        samsung = new Samsung();
        blackberry = new Blackberry();
    }
    
    public void iphoneSale(){
        Iphone.modelNo();
        Iphone.price();
    }
    
    public void samsungSale(){
        samsung.modelNo();
        samsung.price();
    }
    public void blackberrySale(){
        blackberry.modelNo();
        blackberry.price();
    }
}

