/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facadepatterndemo;

/**
 *
 * @author 96657
 */
public class IPhone implements MobileShop {

    @Override
    public void modelNo() {
        System.out.println("Iphone 15");
    }

    @Override
    public void price() {
        System.out.println("5000.00 SAR");
    }
    
    
}
