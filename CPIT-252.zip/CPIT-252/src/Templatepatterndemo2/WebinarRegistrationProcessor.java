/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo2;

/**
 *
 * @author 96657
 */
public class WebinarRegistrationProcessor extends RegistrationProcessor{

    @Override
    void collectData() {
        System.out.println("Collecting data for webinar registration.");
    }

    @Override
    boolean validateData() {
        System.out.println("Validating webinar registration data.");
        // Implement validation logic
        return true;  // Assume data is valid for simplicity

    }

    @Override
    void register() {
        System.out.println("Registering user for the webinar.");
    }
    
}
