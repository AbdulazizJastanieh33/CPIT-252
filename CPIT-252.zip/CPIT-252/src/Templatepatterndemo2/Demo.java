/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo2;

/**
 *
 * @author 96657
 */
public class Demo {
    public static void main(String[]args){
        RegistrationProcessor eventRegistration = new EventRegistrationProcessor();
        RegistrationProcessor workshopRegistration = new WorkshopRegistrationProcessor();
        RegistrationProcessor webinarRegistration = new WebinarRegistrationProcessor();
        
        
        eventRegistration.processRegistration();
        workshopRegistration.processRegistration();
        webinarRegistration.processRegistration();

    }
}
