/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Templatepatterndemo2;

/**
 *
 * @author 96657
 */
public abstract class RegistrationProcessor {
    public final void processRegistration(){
        collectData();
        if (validateData()){
            register();
            sendConfirmationEmail();
        }
        else {
            handleError();
        }
    }
    
    // Collect data
    abstract void collectData();
    
    // Validate data
    abstract boolean validateData();
    
    // Register the user
    abstract void register();

    // Send confirmation email
    private void sendConfirmationEmail() {
        System.out.println("Confirmation email sent.");
    }

    // Handle error
    private void handleError() {
        System.out.println("Validation failed. Unable to register.");
    }

    


}
