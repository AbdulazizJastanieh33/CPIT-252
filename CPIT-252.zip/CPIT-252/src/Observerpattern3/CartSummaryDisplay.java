/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observerpattern3;

/**
 *
 * @author amsum
 */
public class CartSummaryDisplay implements Observer
{
    
    private ShoppingCart cart;
    
    public CartSummaryDisplay(ShoppingCart cart)
    {
        this.cart = cart;
        cart.registerObserver(this);
    }
    
    public void update()
    {
        System.out.println("Total Items in Cart: "+ cart.getItems().size());
        
    }
    
    
    
}