
package Observerpattern3;


public class CartContentsDisplay implements Observer
{
    private ShoppingCart cart;
    
    public CartContentsDisplay(ShoppingCart cart)
    {
        this.cart =cart;
        cart.registerObserver(this);
    }
    
    public void update()
    {
        System.out.println("Cart Contents Updated" + cart.getItems());
    }

        
}
