/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Observerpattern3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 96657
 */
public class ShoppingCart implements Subject{
    private List<Observer> observers;
    private List<String> items;
    
    public ShoppingCart(){
        observers = new ArrayList<>();
        items = new ArrayList<>();
    }
    
    public void registerObserver(Observer o)
    {
        observers.add(o);
    }
    
    public void removeObserver(Observer o)
    {
        observers.remove(o);
    }
    
    public void notifyObservers()
    {
        for (Observer observer : observers) {
            observer.update();
        }
    }
    
    public void addItem(String item)
    {
        items.add(item);
        notifyObservers();
    }
    
    public void removeItem(String item)
    {
        items.remove(item);
        notifyObservers();
    }
    
    public List<String> getItems()
    {
        return items;
    }
    
    
}
