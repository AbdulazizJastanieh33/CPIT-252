/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observerpattern3;

/**
 *
 * @author amsum
 */
public class CartObs 
{
    public static void main(String[] args) 
    {
        ShoppingCart cart = new ShoppingCart();
        new CartContentsDisplay(cart);
        new CartSummaryDisplay(cart);
        
        cart.addItem("Apple");
        cart.addItem("Banana");
        cart.removeItem("Apple");
        
    }
    
}
