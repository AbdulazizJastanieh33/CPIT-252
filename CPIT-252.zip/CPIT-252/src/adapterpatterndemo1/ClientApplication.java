/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapterpatterndemo1;

/**
 *
 * @author 96657
 */
public class ClientApplication {
    public static void main(String[] args) {
        ICalculate targetInterface = new CalculateAdapt();
        targetInterface.calHourly();
        System.out.println(targetInterface.show());
    }
    
}
