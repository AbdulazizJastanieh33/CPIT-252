/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapterpatterndemo1;

/**
 *
 * @author 96657
 */
public class PayCalculator {
    private String empName;

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }
    public void setCalc(int hourly, int rate){
        System.out.println("the Salary is: "+hourly *rate );
    }
    
    
}
