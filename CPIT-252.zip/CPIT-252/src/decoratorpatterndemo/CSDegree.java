/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterndemo;

/**
 *
 * @author 96657
 */
public class CSDegree extends ProgDecorator{
    
    public CSDegree(Program newProgram){
        super(newProgram);
    }
    
    @Override
    public String prepareProg(){
        return super.prepareProg() + "with CS Degree in SAR is :";
        
    }
    
    @Override
    public double progPrice(){
        return super.progPrice() + 16500.00;
    }
    
}
