/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterndemo;

/**
 *
 * @author 96657
 */
public abstract class ProgDecorator implements Program{
    
    
    private Program newProgram;
    
    public ProgDecorator(Program newProgram){
        
        this.newProgram = newProgram;
    }
    
    @Override
    public String prepareProg(){
        return newProgram.prepareProg();
    }
    
    @Override
    public double progPrice(){
        return newProgram.progPrice();
    }
    
    
}
