/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterndemo;

/**
 *
 * @author 96657
 */
public class ITDiploma implements Program {

    @Override
    public String prepareProg() {
        return "IT Diploma fee";
    }

    @Override
    public double progPrice() {
        return 5000.0;
    }
    
}
