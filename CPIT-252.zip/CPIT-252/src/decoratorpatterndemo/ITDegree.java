/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decoratorpatterndemo;

/**
 *
 * @author 96657
 */
public class ITDegree extends ProgDecorator {
    
    public ITDegree(Program newProgram){
        super(newProgram);
    }
    
    
    @Override
    public String prepareProg(){
        return super.prepareProg()+ "IT Degree Fee in SAR is :";
    }
    
    @Override
    public double progPrice(){
        return super.progPrice() + 15000.00;
    }
    
    
}
