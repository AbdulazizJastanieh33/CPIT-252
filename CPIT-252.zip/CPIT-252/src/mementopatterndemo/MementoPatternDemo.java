/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementopatterndemo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 96657
 */
public class MementoPatternDemo {
    public static void main(String[]args){
        
        List<Life.Memento> savedTimes = new ArrayList<Life.Memento>();
        
        Life life = new Life();
        //time travel and record the eras
        
        life.set("2000 B.C.");
        savedTimes.add(life.saveToMemento());
        
        life.set("2000 A.D");
        savedTimes.add(life.saveToMemento());
        
        life.set("3000 A.D");
        savedTimes.add(life.saveToMemento());
        
        life.set("4000 A.D");
        
        life.restoreFromMemento(savedTimes.get(0));
        
        
    }
}
