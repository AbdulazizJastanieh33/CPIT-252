/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpatterndemo;

/**
 *
 * @author 2135813
 */
public class HighManagementObs implements Observer{
    private Employee emp;
    
    
    public HighManagementObs(Employee employee){
        this.emp = employee;
        this.emp.addObserver(this);
    }
    
    public void sendMessage(){
        System.out.println("High Management is informed about the new salary " + emp.getSalary() + ") of Mr. "+ emp.getName());
        
    }
    
    
}
