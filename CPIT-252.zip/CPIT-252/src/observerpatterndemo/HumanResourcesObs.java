/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpatterndemo;

/**
 *
 * @author 2135813
 */
public class HumanResourcesObs implements Observer{
    private Employee emp;
    public HumanResourcesObs(Employee employee){
        this.emp = employee;
        this.emp.addObserver(this);
    }

    @Override
    public void sendMessage() {
        System.out.println("Human Resources are informed about the new salary ("  + emp.getSalary() + ") of Mr. "+ emp.getName() );
    }
    
    
    
    
}
