/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementopatterndemo2;

/**
 *
 * @author 96657
 */
public class GameCharacter {
    private int powerLevel = 0;
    
    public void setPowerLevel(int level){
        this.powerLevel = level;
        System.out.println("Character power Level:" +powerLevel);
        
    }
    
    public CharacterMemento Save(){
        return new CharacterMemento(powerLevel);
    }
    
    public void restoreFromMemento(CharacterMemento memento){
        powerLevel = memento.getPowerLevel();
        System.out.println("Restored Power Level:" + powerLevel);
        
}
}
