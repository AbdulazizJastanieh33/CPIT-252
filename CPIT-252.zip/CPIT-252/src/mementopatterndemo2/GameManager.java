/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementopatterndemo2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 96657
 */
public class GameManager {
    private List<CharacterMemento> savedStates = new ArrayList<>();
    
    public void saveState(CharacterMemento memento){
        savedStates.add(memento);
    }
    
    public CharacterMemento getState(int index){
        return savedStates.get(index);
    }
    
    
}
