/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mementopatterndemo2;

/**
 *
 * @author 96657
 */
public class CharacterMemento {
    private int powerLevel;
    
    public CharacterMemento(int level){
        this.powerLevel = level;
    }
    
    public int getPowerLevel(){
        return powerLevel;
    }
}
