/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package commandpatterndemo1;

/**
 *
 * @author 96657
 */
public class Document {
    public void open(){
        System.out.println("Document Opened");
    }
    
    public void save(){
        System.out.println("Document saved");
    }
    
    
}
