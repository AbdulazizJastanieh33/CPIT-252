/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package commandpatterndemo1;

/**
 *
 * @author 96657
 */
public class MenuOption {
    private Command1 openCommand;
    private Command1 SaveCommand;
    
    public MenuOption(Command1 open, Command1 save){
        
        this.openCommand = open;
        this.SaveCommand = save;
        
    }
    
    public void clickOpen(){
        openCommand.execute();
    }
    
    public void clickSave(){
        SaveCommand.execute();
    }
    
    
}
