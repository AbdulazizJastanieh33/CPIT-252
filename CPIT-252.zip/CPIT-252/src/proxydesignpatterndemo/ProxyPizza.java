/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proxydesignpatterndemo;

/**
 *
 * @author 96657
 */
public class ProxyPizza extends PizzaSubject {
    
    @Override
    public void name(){
        super.name();
    }
    @Override
    public void size(){
        super.size();
    }
    @Override
    public void price(){
        super.price();
    }
    
    
}
