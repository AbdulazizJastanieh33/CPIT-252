/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proxydesignpatterndemo;

/**
 *
 * @author 96657
 */
public class PizzaSubject implements Pizza {

    @Override
    public void name() {
        System.out.println("Veg Pizza is available");
    }

    @Override
    public void size() {
        System.out.println("in a standard size and price in SAR is:");
    }

    @Override
    public void price() {
        System.out.println("150 \n");
    }
    
    
}
