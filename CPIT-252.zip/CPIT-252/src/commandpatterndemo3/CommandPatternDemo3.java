/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package commandpatterndemo3;

/**
 *
 * @author 96657
 */
public class CommandPatternDemo3 {
    public static void main(String[]args){
        
        
        Light livingRoomLight = new Light();
        Command lightsOn = new LightOnCommand(livingRoomLight);
        Command lightsOff = new LightOffCommand(livingRoomLight);
        
        RemoteControl remote = new RemoteControl(lightsOn);
        remote.pressButton();   
        
        remote = new RemoteControl(lightsOff);
        remote.pressButton();
        
        
    }
}
