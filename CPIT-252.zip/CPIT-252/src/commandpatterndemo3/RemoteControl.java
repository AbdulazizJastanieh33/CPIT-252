/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package commandpatterndemo3;

/**
 *
 * @author 96657
 */
public class RemoteControl {
    private Command command;
    
    public RemoteControl(Command command){
        this.command = command;
    }
    
    public void pressButton(){
        command.execute();
    }
    
    
}
