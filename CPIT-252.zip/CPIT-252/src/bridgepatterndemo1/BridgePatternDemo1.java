/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridgepatterndemo1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author 96657
 */
public class BridgePatternDemo1 {
    static int choice;
    
    public static void main(String[]args) throws IOException{
        Shape Obj1 = new Circle();
        Shape Obj2 = new Rectangle();
        Shape Obj3 = new Sphere();
        
        do
        {
            System.out.println("================= Shape Area and Volume Options ====================");
            System.out.println("    1. Circle       \n");
            System.out.println("    2. Rectangle    \n");
            System.out.println("    3. Sphere       \n");
            System.out.println("    4. Exit         \n");
            System.out.println("Enter your choice: ");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            choice = Integer.parseInt(br.readLine());
            
            switch(choice)
            {
                case 1: 
                {
                    Obj1.area();
                    Obj2.volume();
                }
                break;
                
                case 2:
                {
                    Obj2.area();
                    Obj2.volume();
                    
                }
                break;
                
                case 3:
                {
                    Obj3.area();
                    Obj3.volume();
                    
                }
                break;
                
                default:
                {
                    System.out.println("Nothing you select");
                }
                return;
            }
            
        } while(choice !=4);
        
        
        }
        
        
    
}
