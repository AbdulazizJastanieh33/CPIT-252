/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridgepatterndemo1;

/**
 *
 * @author 96657
 */
public class Rectangle implements Shape{
    public void area()
    {
        System.out.println("The area of Rectangle is: "+3*3+"\n");
        
    }
    
    public void volume()
    {
        System.out.println("The Volume of Rectangle: "+3*3*3+"\n");
    }
}
