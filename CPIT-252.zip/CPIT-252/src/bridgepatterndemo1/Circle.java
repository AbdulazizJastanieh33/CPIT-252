/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridgepatterndemo1;

/**
 *
 * @author 96657
 */
public class Circle implements Shape{

    @Override
    public void area() {
        System.out.println("The area of circle is:" + 3.14*2+"\n");
    }

    @Override
    public void volume() {
        
        System.out.println("Volume of circle can not be calculated" + "\n");
    }
    
    
}
