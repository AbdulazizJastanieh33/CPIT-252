/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observerpatterndemo2;

/**
 *
 * @author 96657
 */
public class WeatherObserver {
    
    public static void main(String[]args){
        WeatherData weatherData = new WeatherData();
        CurrentConditionsDisplay currentDisplay = new CurrentConditionsDisplay();
        
        weatherData.registerObserver(currentDisplay);
        
        weatherData.setMeasurements(30.4f, 65, 80);
        weatherData.setMeasurements(29.2f, 70, 82);
    }
    
    
}
